# DOC-IQ: Intelligent Document Processing Pipeline

DOC-IQ is a comprehensive document processing system that uses OCR and AI to extract structured data from various document types including resumes, driver's licenses, and receipts.

## 🚀 Features

### Document Types Supported
- **Resumes**: Extract FullName, Email, PhoneNumber, Skills, WorkExperience, Education
- **Driver's Licenses**: Extract Name, DateOfBirth, LicenseNumber, IssuingState, ExpiryDate
- **Receipts**: Extract StoreName, LineItems, TotalAmount, PaymentMethod, and more with discrepancy detection

### Key Capabilities
- **OCR Processing**: Uses EasyOCR for robust text extraction
- **AI-Powered Parsing**: OpenAI GPT-4o-mini for intelligent field extraction
- **Validation Logic**: Built-in validation with discrepancy detection
- **Batch Processing**: Process multiple documents efficiently
- **CLI Interface**: Easy-to-use command-line tools
- **API Ready**: FastAPI backend for web integration

## 📁 Project Structure

```
DOC-IQ/
├── doc_pipeline/
│   ├── pipeline/generic_pipeline.py    # Main processing pipeline
│   ├── llm/llm_client.py               # OpenAI integration
│   ├── prompts/                        # AI prompts for each document type
│   │   ├── resume_extraction.txt
│   │   ├── license_extraction.txt
│   │   └── receipt_extraction.txt
│   ├── ocr/ocr_engine.py               # OCR processing engine
│   ├── utils/
│   │   ├── validators.py               # Data validation logic
│   │   └── file_utils.py               # File handling utilities
│   ├── config.py                       # Configuration settings
│   ├── cli.py                          # Command-line interface
│   └── main.py                         # Main application entry point
├── test/                               # Test scripts
├── test/output/                        # Processed results
│   ├── resume/                         # Resume extraction results
│   ├── driving_license/                # License extraction results
│   └── shop_receipts/                  # Receipt extraction results
└── requirements.txt                    # Python dependencies
```

## 🛠 Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd DOC-IQ
   ```

2. **Create virtual environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Set up OpenAI API key**
   ```bash
   export OPENAI_API_KEY="your-api-key-here"
   ```

## 📖 Usage

### Command Line Interface

**Process a single document:**
```bash
python doc_pipeline/cli.py --mode resume --input path/to/resume.jpg --output test/output/resume --prompt_dir doc_pipeline/prompts
```

**Process a directory of documents:**
```bash
python doc_pipeline/cli.py --mode receipt --input doc_pipeline/data/shop_receipts --output test/output/shop_receipts --prompt_dir doc_pipeline/prompts
```

### Supported Modes
- `resume` - Extract resume information
- `license` - Extract driver's license information  
- `receipt` - Extract receipt information with discrepancy detection

### Test Scripts

**Test Resume Parser:**
```bash
python test_resume_parser.py
```

**Test License Parser:**
```bash
python test_license_parser.py
```

**Test Receipt Parser:**
```bash
python test_receipt_parser.py
```

## 📊 Results

### Resume Processing
- **Success Rate**: 100% (31/31 files processed)
- **Fields Extracted**: FullName, Email, PhoneNumber, Skills, WorkExperience, Education
- **Output Format**: Structured JSON with validation

### Driver's License Processing
- **Success Rate**: 82% (9/11 files processed)
- **Fields Extracted**: Name, DateOfBirth, LicenseNumber, IssuingState, ExpiryDate
- **Special Features**: Strict name extraction from numbered fields
- **Output Format**: Validated JSON with required field enforcement

### Receipt Processing
- **Success Rate**: 100% (22/22 files processed)
- **Fields Extracted**: StoreName, LineItems, TotalAmount, PaymentMethod, CardLast4Digits
- **Special Features**: Discrepancy detection with 2% tolerance
- **Output Format**: Unified JSON format with comprehensive validation

## 🔧 Technical Details

### OCR Engine
- **Engine**: EasyOCR with CPU optimization
- **Languages**: English (configurable for multi-language support)
- **Preprocessing**: Automatic image enhancement and noise reduction

### AI Integration
- **Model**: OpenAI GPT-4o-mini
- **Temperature**: 0.0 (deterministic output)
- **Max Tokens**: 2048
- **Prompt Engineering**: Specialized prompts for each document type

### Validation Logic
- **Required Fields**: Enforced per document type
- **Data Types**: Automatic type conversion and validation
- **Discrepancy Detection**: Mathematical validation for receipts
- **Error Handling**: Graceful failure with detailed error messages

## 📈 Performance Metrics

| Document Type | Files Processed | Success Rate | Avg Processing Time |
|---------------|----------------|--------------|-------------------|
| Resumes       | 31             | 100%         | ~15 seconds       |
| Licenses      | 11             | 82%          | ~12 seconds       |
| Receipts      | 22             | 100%         | ~18 seconds       |

## 🚨 Discrepancy Detection

The receipt parser includes intelligent discrepancy detection:
- **Tolerance**: 2% difference threshold
- **Detection**: Automatically flags when sum of items ≠ total amount
- **Warnings**: Logged but don't fail validation
- **Use Cases**: Helps identify OCR errors or missing items

## 🔒 Security & Privacy

- **API Keys**: Environment variable based configuration
- **Data Processing**: Local OCR processing, secure API calls
- **Output**: Structured JSON without sensitive data exposure
- **Validation**: Input sanitization and type checking

## 🛠 Development

### Adding New Document Types

1. Create a new prompt file in `doc_pipeline/prompts/`
2. Update `doc_pipeline/utils/validators.py` with validation schema
3. Test with sample data
4. Update CLI interface if needed

### Customizing Prompts

Edit the prompt files in `doc_pipeline/prompts/` to:
- Change field extraction logic
- Add new fields
- Modify validation rules
- Improve accuracy for specific document types

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📞 Support

For questions or issues:
- Create an issue in the repository
- Check the test scripts for examples
- Review the validation logic for troubleshooting

---

**DOC-IQ** - Intelligent Document Processing Made Simple 