import json
from pathlib import Path
from ocr.ocr_engine import extract_text_from_file
from llm.llm_client import extract_fields_from_text
from utils.validators import validate_output

def process_document(file_path: str, doc_type: str, prompt_dir: str):
    """
    Process a document: OCR, prompt, LLM extraction, validation.
    Args:
        file_path: Path to the input file
        doc_type: Document type (e.g., 'resume', 'license', 'receipt')
        prompt_dir: Directory containing prompt templates
    Returns:
        Validated data as JSON
    """
    # 1. OCR
    ocr_text = extract_text_from_file(file_path)
    if not ocr_text:
        raise ValueError(f"No text extracted from {file_path}")

    # 2. Load prompt
    prompt_path = Path(prompt_dir) / f"{doc_type}_extraction.txt"
    if not prompt_path.exists():
        raise FileNotFoundError(f"Prompt not found: {prompt_path}")
    with open(prompt_path, 'r', encoding='utf-8') as f:
        prompt = f.read()

    # 3. LLM extraction
    data = extract_fields_from_text(ocr_text, prompt)

    # 4. Validate output
    validated = validate_output(data, doc_type)

    # 5. Return as JSON
    return json.dumps(validated, ensure_ascii=False, indent=2) 